using UnityEngine;

public enum HarvestResourceKind
{
    Unknown,
    LinhMe,
    Ca,
    Thit,
    ThaoDuoc
}

[RequireComponent(typeof(WorldStatItemPickup))]
public class ResourceNode : MonoBehaviour
{
    public WorldStatItemPickup pickup;
    public HarvestResourceKind resourceKind = HarvestResourceKind.Unknown;

    void Awake()
    {
        if (pickup == null)
        {
            pickup = GetComponent<WorldStatItemPickup>();
        }

        RefreshResourceKind();
    }

    void OnValidate()
    {
        if (pickup == null)
        {
            pickup = GetComponent<WorldStatItemPickup>();
        }

        RefreshResourceKind();
    }

    public void RefreshResourceKind()
    {
        if (pickup == null)
        {
            return;
        }

        resourceKind = InferKindFromItem(pickup.item);
    }

    public bool Matches(StatItemData item)
    {
        if (pickup == null || item == null)
        {
            return false;
        }

        if (pickup.item == item)
        {
            return true;
        }

        return InferKindFromItem(item) == resourceKind;
    }

    public static HarvestResourceKind InferKindFromItem(StatItemData item)
    {
        if (item == null)
        {
            return HarvestResourceKind.Unknown;
        }

        string itemName = (item.itemName ?? string.Empty).ToLowerInvariant();
        string assetName = (item.name ?? string.Empty).ToLowerInvariant();

        if (itemName.Contains("linh") ||
            assetName.Contains("linh") ||
            item.ItemId == "46fa9c5a1da91f041b6da40762359694")
        {
            return HarvestResourceKind.LinhMe;
        }

        if (itemName.Contains("ca") || assetName.Contains("ca"))
        {
            return HarvestResourceKind.Ca;
        }

        if (itemName.Contains("thit") ||
            itemName.Contains("thịt") ||
            assetName.Contains("thit"))
        {
            return HarvestResourceKind.Thit;
        }

        if (itemName.Contains("thao") ||
            itemName.Contains("thuoc") ||
            itemName.Contains("dược") ||
            assetName.Contains("thao") ||
            assetName.Contains("thuoc"))
        {
            return HarvestResourceKind.ThaoDuoc;
        }

        return HarvestResourceKind.Unknown;
    }
}
